# http2-flooder

New http2 flooder, leaked because the developer said his scripts are better than mine 


curl -sL https://deb.nodesource.com/setup_16.x | sudo bash -
sudo apt -y install nodejs

npm i http http2 crypto tls

node tls.js https://website.com 120

Put HTTP proxies inside proxy.txt and user agents inside ua.txt
