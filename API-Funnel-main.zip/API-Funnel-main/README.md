# API-Funnel for DDos

**Send Attack:** http://localhost:1337/api/attack?host=[HOST]&port=[PORT]&time=[TIME]&method=[METHOD]


![image](https://user-images.githubusercontent.com/66147422/212499864-e592bcfb-ba37-4e03-861d-96811ca81c70.png)


`This repo is for educational purposes.`
